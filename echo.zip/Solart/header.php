<div class="container">
        <header class="clearfix" id="header">
            <nav class="navbar navbar-default">
               <div class="container">
                   <!-- Brand and toggle get grouped for better mobile display -->
                   <div class="navbar-header">
                       <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                           data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                           <span class="sr-only">Toggle navigation</span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                       </button>
                       <a class="navbar-brand" href="/"><img alt="solar rooftop india" src="https://ik.imagekit.io/dbekk5x4n/logo/logo.png"></a>
                   </div>
                   <!-- Collect the nav links, forms, and other content for toggling -->
                   <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                       <ul class="nav navbar-nav navbar-right">
                           <li class=""><a href="index.php">Home <span class="sr-only">(current)</span></a></li>
                           <li class=""><a href="aboutus.php">About Us <span class="sr-only">(current)</span></a></li>
                           <!-- Upload nav -->
                           <li ><a class="nav-link "
                            href="operations.php">Our Operations </a>
                                <!-- <ul class="dropdown-menu">
        
                                    <li class="dropdown"><a class="dropdown-item dropdown-toggle"
                                            href="goa.php">GOA  </a>
                                    </li>
                                    <li class="dropdown"><a class="dropdown-item dropdown-toggle"
                                            href="maharashtra.php">MAHARASHTRA </a>
                                    </li>
                                    <li class="dropdown"><a class="dropdown-item dropdown-toggle"
                                            href="bihar.php">BIHAR </a>
                                    </li>
                                       
                                    
        
                                
                                    
                                    
                                </ul> -->
                         </li>
        
                        
                         <li><a href="marketsegments.php">Market Segments</a></li>
                             <li><a href="whychooseus.php">Why Choose Us</a></li>
                           <li><a href="contactus.php">Contact us</a></li>
                           
                           
                       </ul>
                   </div>
               </div>
           </nav>
         </header>
    </div>